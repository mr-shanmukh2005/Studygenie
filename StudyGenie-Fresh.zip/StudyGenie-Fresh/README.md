# StudyGenie — fresh frontend

A fresh React + Vite frontend using the Midnight Navy theme.

## Requirements
- Node.js (LTS recommended)
- The backend can be added later; the UI can run independently.

## Run locally
1. Extract this project.
2. Open the extracted `StudyGenie-Fresh` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:
   ```cmd
   npm.cmd install
   ```
5. Then run:
   ```cmd
   npm.cmd run dev
   ```
6. Open the local URL printed in the terminal.

## Backend integration
Copy `.env.example` to `.env` and set `VITE_API_BASE_URL` to the FastAPI base URL.
The API helper is in `src/services/api.js`. Endpoint paths and payload shapes must be matched to the backend's actual API before enabling real data operations. The chatbot page includes an integration-ready request path but will show a clear connection error if the backend/chat endpoint is not ready.

## Current behavior
- The interface starts with empty subjects, assignments, planner, and progress states.
- No demo academic records are preloaded.
- Login and registration are frontend screens only until backend authentication routes are confirmed.
- The chatbot UI is present; it needs the actual backend chat endpoint and response shape confirmed.
