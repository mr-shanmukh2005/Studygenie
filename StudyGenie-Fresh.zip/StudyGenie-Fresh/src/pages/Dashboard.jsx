import { ArrowUpRight, BookOpen, CalendarClock, CheckCircle2, Clock3, Sparkles } from 'lucide-react'
import { Link } from 'react-router-dom'
import EmptyState from '../components/EmptyState'
import SectionTitle from '../components/SectionTitle'

const metrics = [
  {label:'Active subjects', value:'—', note:'Add your first subject', icon:BookOpen, tone:'blue'},
  {label:'Tasks to complete', value:'—', note:'Your tasks will show here', icon:CheckCircle2, tone:'violet'},
  {label:'Study time', value:'—', note:'Track your sessions', icon:Clock3, tone:'teal'},
  {label:'Upcoming exams', value:'—', note:'Keep important dates close', icon:CalendarClock, tone:'amber'},
]
export default function Dashboard() {
  return <div className="dashboard-stack">
    <section className="welcome-banner"><div className="welcome-content"><div className="welcome-kicker"><Sparkles size={14}/> YOUR PERSONAL STUDY SPACE</div><h2>Make room for what<br/><span>you want to learn.</span></h2><p>Start with one subject, one goal, or one focused session. We'll help you keep it all organized.</p><Link className="button button-light" to="/subjects">Set up your subjects <ArrowUpRight size={16}/></Link></div><div className="banner-art" aria-hidden="true"><div className="banner-ring ring-a"/><div className="banner-ring ring-b"/><div className="banner-book"><BookOpen size={55}/></div><div className="float-card float-card-top"><Sparkles size={15}/><span>Learn at your pace</span></div><div className="float-card float-card-bottom"><CheckCircle2 size={16}/><span>Progress, one step at a time</span></div></div></section>
    <div className="metrics-grid">{metrics.map(({label,value,note,icon:Icon,tone})=><article className="metric-card" key={label}><div className={`metric-icon ${tone}`}><Icon size={19}/></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-note">{note}</div></article>)}</div>
    <div className="dashboard-columns"><section className="panel"><SectionTitle title="Your learning" subtitle="Your subjects will live here."/><EmptyState type="subjects" title="Your learning starts here" description="Add a subject and its topics to create your personal learning map." action="Add a subject" onAction={()=>location.href='/subjects'}/></section><section className="panel"><SectionTitle title="Coming up" subtitle="Deadlines and study sessions."/><EmptyState type="assignments" title="Nothing scheduled yet" description="When you add assignments or plan study sessions, you'll see them here." action="View assignments" onAction={()=>location.href='/assignments'}/></section></div>
    <section className="assistant-promo"><div className="promo-icon"><Sparkles size={22}/></div><div className="promo-copy"><h3>Meet your AI study companion</h3><p>Get a concept explained, generate practice questions, or work through a tricky topic.</p></div><Link className="button button-outline" to="/assistant">Open AI assistant <ArrowUpRight size={16}/></Link></section>
  </div>
}