import { useState } from 'react'
import { Plus, Search, SlidersHorizontal } from 'lucide-react'
import EmptyState from '../components/EmptyState'
import SectionTitle from '../components/SectionTitle'
export default function Assignments(){
 const [showForm,setShowForm]=useState(false)
 return <div className="page-stack"><section className="panel"><SectionTitle title="Assignment tracker" subtitle="Keep every deadline in one place." action={<button className="button button-primary" onClick={()=>setShowForm(!showForm)}><Plus size={16}/>{showForm?'Close':'Add assignment'}</button>}/>
 {showForm&&<div className="notice notice-info">The form will be wired to the backend after we confirm its assignment fields and endpoint.</div>}
 <div className="filter-row"><div className="input-with-icon"><Search size={16}/><input placeholder="Search assignments" aria-label="Search assignments"/></div><button className="button button-outline"><SlidersHorizontal size={15}/> Filters</button></div>
 <div className="tabs"><button className="tab active">All tasks <span>0</span></button><button className="tab">To do <span>0</span></button><button className="tab">Completed <span>0</span></button></div>
 <EmptyState type="assignments" title="A clear desk to start" description="No assignments have been added. Once connected, you can track due dates, priority, and completion here." action="Add your first assignment" onAction={()=>setShowForm(true)}/></section></div>
}