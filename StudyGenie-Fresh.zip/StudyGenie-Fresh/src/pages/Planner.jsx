import { useState } from 'react'
import { CalendarDays, ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import EmptyState from '../components/EmptyState'
import SectionTitle from '../components/SectionTitle'
export default function Planner(){
 const [showForm,setShowForm]=useState(false)
 return <div className="page-stack"><section className="panel"><SectionTitle title="Study calendar" subtitle="Give your learning a little space on the calendar." action={<button className="button button-primary" onClick={()=>setShowForm(!showForm)}><Plus size={16}/>{showForm?'Close':'Plan a session'}</button>}/>
 <div className="calendar-toolbar"><div className="calendar-month"><CalendarDays size={18}/><strong>Your schedule</strong><span className="muted-label">No sessions yet</span></div><div className="calendar-arrows"><button className="icon-button" aria-label="Previous week"><ChevronLeft size={18}/></button><button className="icon-button" aria-label="Next week"><ChevronRight size={18}/></button></div></div>
 {showForm&&<div className="notice notice-info">Session creation will be connected when we confirm the backend study-session endpoint and required fields.</div>}
 <EmptyState type="planner" title="Make time for learning" description="Your planner is ready. Add study sessions after the backend is connected." action="Plan your first session" onAction={()=>setShowForm(true)}/></section></div>
}