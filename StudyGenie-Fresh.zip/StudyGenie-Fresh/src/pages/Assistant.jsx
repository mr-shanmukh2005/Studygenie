import { useState, useRef, useEffect } from 'react'
import { Bot, BrainCircuit, BookOpen, Send, Sparkles, UserRound, RotateCcw } from 'lucide-react'
import { sendChatMessage } from '../services/api'

const suggestions = [
 {icon:BookOpen,title:'Explain a concept',text:'Explain a difficult topic in simple words.'},
 {icon:BrainCircuit,title:'Practice with me',text:'Create practice questions for a topic I choose.'},
 {icon:Sparkles,title:'Plan my study',text:'Help me make a realistic study plan.'},
]
export default function Assistant(){
 const [messages,setMessages]=useState([])
 const [input,setInput]=useState('')
 const [busy,setBusy]=useState(false)
 const [error,setError]=useState('')
 const listRef=useRef(null)
 useEffect(()=>{if(listRef.current)listRef.current.scrollTop=listRef.current.scrollHeight},[messages,busy])
 async function send(text=input){
  const message=text.trim(); if(!message||busy)return
  const next=[...messages,{role:'user',content:message}]
  setMessages(next);setInput('');setError('');setBusy(true)
  try{
   const result=await sendChatMessage(message,next.map(m=>({role:m.role,content:m.content})))
   const answer=typeof result==='string'?result:(result?.response||result?.answer||result?.message||result?.reply)
   if(!answer)throw new Error('The backend replied, but its response format needs to be mapped in src/services/api.js.')
   setMessages([...next,{role:'assistant',content:answer}])
  }catch(e){setError(`${e.message}. The chat endpoint may not be ready yet; we'll match it to your backend when available.`)}
  finally{setBusy(false)}
 }
 function reset(){setMessages([]);setError('')}
 return <div className="chat-layout"><section className="chat-panel"><div className="chat-topline"><div className="chat-avatar"><Bot size={21}/></div><div><strong>StudyGenie Assistant</strong><span><i className="status-dot"/> Ready to help when connected</span></div><button className="icon-button chat-reset" title="Clear conversation" onClick={reset}><RotateCcw size={17}/></button></div>
 <div className="chat-messages" ref={listRef}>
 {messages.length===0?<div className="chat-welcome"><div className="chat-orb"><Sparkles size={29}/></div><p className="eyebrow">YOUR AI STUDY COMPANION</p><h2>What are we learning<br/><span>today?</span></h2><p className="chat-intro">Ask a question, untangle a tricky concept, or practice for your next exam. Let's work through it together.</p><div className="suggestion-grid">{suggestions.map(({icon:Icon,title,text})=><button className="suggestion-card" key={title} onClick={()=>setInput(text)}><span className="suggestion-icon"><Icon size={17}/></span><strong>{title}</strong><span>{text}</span></button>)}</div></div>:<div className="message-list">{messages.map((m,i)=><div className={`message-row ${m.role}`} key={i}><div className={`message-avatar ${m.role}`}>{m.role==='user'?<UserRound size={16}/>:<Bot size={16}/>}</div><div className="message-bubble"><span className="message-name">{m.role==='user'?'You':'StudyGenie'}</span><p>{m.content}</p></div></div>)}{busy&&<div className="message-row assistant"><div className="message-avatar assistant"><Bot size={16}/></div><div className="message-bubble"><span className="message-name">StudyGenie</span><p className="typing"><i/><i/><i/></p></div></div>}</div>}
 </div>
 {error&&<div className="chat-error" role="alert">{error}</div>}
 <form className="chat-composer" onSubmit={e=>{e.preventDefault();send()}}><textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask StudyGenie anything about your studies..." rows="1" onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}}/><button type="submit" className="send-button" disabled={!input.trim()||busy} aria-label="Send message"><Send size={18}/></button><span className="composer-hint">Enter to send · Shift + Enter for a new line</span></form>
 </section><aside className="chat-side"><div className="side-feature"><div className="side-feature-icon"><BrainCircuit size={20}/></div><h3>Learn in your own way</h3><p>Use your assistant to understand topics, generate revision questions, and plan your next steps.</p></div><div className="side-info"><h4>Things you can ask</h4>{['Explain a concept simply','Give me a practice quiz','Compare two ideas','Help plan a revision session'].map((s,i)=><div className="side-info-item" key={s}><span>0{i+1}</span>{s}</div>)}</div><div className="privacy-note"><span className="privacy-dot"/><p>Chat responses are requested through your StudyGenie backend. The AI service key should stay on the server.</p></div></aside></div>
}