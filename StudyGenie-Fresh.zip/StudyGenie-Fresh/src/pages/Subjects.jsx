import { useState } from 'react'
import { Plus, Search } from 'lucide-react'
import EmptyState from '../components/EmptyState'
import SectionTitle from '../components/SectionTitle'

export default function Subjects() {
  const [showForm,setShowForm] = useState(false)
  const [name,setName] = useState('')
  const [notice,setNotice] = useState('')
  function submit(e){e.preventDefault();setNotice('The backend subject endpoint is not connected yet. Your subject has not been saved.');}
  return <div className="page-stack"><section className="panel"><SectionTitle title="Subject library" subtitle="Keep your topics organized by subject." action={<button className="button button-primary" onClick={()=>{setShowForm(!showForm);setNotice('')}}><Plus size={16}/>{showForm?'Close':'Add subject'}</button>}/>
  {showForm && <form className="inline-form" onSubmit={submit}><label htmlFor="subject-name">Subject name</label><div className="form-row"><input id="subject-name" value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Python programming" required/><button className="button button-primary" type="submit">Save subject</button></div><p className="form-hint">We'll enable saving once the backend endpoint is confirmed.</p></form>}
  {notice && <div className="notice notice-info">{notice}</div>}
  <div className="filter-row"><div className="input-with-icon"><Search size={16}/><input aria-label="Search subjects" placeholder="Search your subjects" /></div><span className="count-pill">0 subjects</span></div>
  <EmptyState type="subjects" title="No subjects yet" description="Your subject library is empty by design. Add subjects when you're ready, then connect this page to the backend to save them." action="Create your first subject" onAction={()=>setShowForm(true)}/></section></div>
}