import { BookOpen, ClipboardList, CalendarDays, ChartNoAxesCombined, Plus, Sparkles } from 'lucide-react'
const icons = { subjects: BookOpen, assignments: ClipboardList, planner: CalendarDays, progress: ChartNoAxesCombined, default: Sparkles }
export default function EmptyState({type='default', title, description, action, onAction}) {
  const Icon = icons[type] || icons.default
  return <div className="empty-state"><div className="empty-illustration"><div className="empty-orbit orbit-one"/><div className="empty-orbit orbit-two"/><div className="empty-icon"><Icon size={27}/></div><span className="sparkle sparkle-a">✦</span><span className="sparkle sparkle-b">✧</span></div><h3>{title}</h3><p>{description}</p>{action && <button className="button button-primary" onClick={onAction}><Plus size={16}/>{action}</button>}</div>
}