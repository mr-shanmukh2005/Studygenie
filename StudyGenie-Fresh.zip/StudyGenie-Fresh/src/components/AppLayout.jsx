import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { BookOpen, Bot, CalendarDays, ChartNoAxesCombined, ClipboardList, GraduationCap, LayoutDashboard, Menu, Search, Sparkles, X } from 'lucide-react'
import { useState } from 'react'

const navItems = [
  { to: '/', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/subjects', label: 'My subjects', icon: BookOpen },
  { to: '/assignments', label: 'Assignments', icon: ClipboardList },
  { to: '/planner', label: 'Study planner', icon: CalendarDays },
  { to: '/progress', label: 'Progress', icon: ChartNoAxesCombined },
]
const titles = {
  '/': ['Good to see you', 'Here’s your learning space. Start by adding your subjects and study tasks.'],
  '/subjects': ['My subjects', 'Organize the subjects and topics you are learning.'],
  '/assignments': ['Assignments', 'Keep track of deadlines and what needs your attention.'],
  '/planner': ['Study planner', 'Make time for focused learning, one session at a time.'],
  '/progress': ['Your progress', 'Your learning insights will appear here as you study.'],
  '/assistant': ['StudyGenie AI', 'Ask questions, explore concepts, and practice what you learn.'],
}
export default function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()
  const heading = titles[location.pathname] || titles['/']
  return <div className="app-shell">
    {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><GraduationCap size={23} /></div>
        <div><div className="brand-name">StudyGenie</div><div className="brand-tag">YOUR LEARNING SPACE</div></div>
        <button className="icon-button sidebar-close" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X size={18}/></button>
      </div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="main-nav">
        {navItems.map(({to,label,icon:Icon,end}) => <NavLink key={to} to={to} end={end} onClick={() => setMobileOpen(false)} className={({isActive}) => `nav-link ${isActive ? 'active' : ''}`}><Icon size={18}/><span>{label}</span></NavLink>)}
      </nav>
      <div className="sidebar-divider" />
      <div className="workspace-label">YOUR COMPANION</div>
      <NavLink to="/assistant" onClick={() => setMobileOpen(false)} className={({isActive}) => `nav-link assistant-nav ${isActive ? 'active' : ''}`}><Bot size={18}/><span>AI study assistant</span><span className="nav-new">AI</span></NavLink>
      <div className="sidebar-bottom">
        <div className="sidebar-tip"><div className="tip-icon"><Sparkles size={17}/></div><strong>Small steps add up.</strong><p>Your next study session is a chance to make progress.</p><NavLink to="/planner">Plan a session <span>→</span></NavLink></div>
        <div className="profile-row"><div className="avatar">S</div><div className="profile-copy"><strong>Student workspace</strong><span>Personal learning</span></div><span className="online-dot" /></div>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar">
        <button className="icon-button mobile-menu" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu size={21}/></button>
        <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{heading[0]}</strong></div>
        <div className="top-actions"><div className="search-pill"><Search size={16}/><span>StudyGenie</span><kbd>⌘ K</kbd></div><div className="top-avatar">S</div></div>
      </header>
      <div className="page-content">
        <div className="page-heading"><div><p className="eyebrow">STUDYGENIE WORKSPACE</p><h1>{heading[0]}</h1><p className="page-subtitle">{heading[1]}</p></div><div className="date-chip"><span className="date-dot"/><span>Your space, your pace</span></div></div>
        <Outlet />
      </div>
      <footer className="app-footer"><span>StudyGenie</span><span>Learn smarter. Plan better.</span></footer>
    </main>
  </div>
}