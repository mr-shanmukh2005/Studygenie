export default function SectionTitle({title, subtitle, action}) {
  return <div className="section-title-row"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{action}</div>
}