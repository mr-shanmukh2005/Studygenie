import { Navigate, Route, Routes } from 'react-router-dom'
import AppLayout from './components/AppLayout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Subjects from './pages/Subjects'
import Assignments from './pages/Assignments'
import Planner from './pages/Planner'
import Progress from './pages/Progress'
import Assistant from './pages/Assistant'

export default function App() {
  return <Routes>
    <Route path="/login" element={<Login />} />
    <Route element={<AppLayout />}>
      <Route index element={<Dashboard />} />
      <Route path="/subjects" element={<Subjects />} />
      <Route path="/assignments" element={<Assignments />} />
      <Route path="/planner" element={<Planner />} />
      <Route path="/progress" element={<Progress />} />
      <Route path="/assistant" element={<Assistant />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
}