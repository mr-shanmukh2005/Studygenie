const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')

export async function apiRequest(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  })
  const raw = await response.text()
  let data = null
  try { data = raw ? JSON.parse(raw) : null } catch { data = raw }
  if (!response.ok) {
    const detail = data && typeof data === 'object' ? (data.detail || data.message) : null
    throw new Error(detail || `Request failed (${response.status})`)
  }
  return data
}

/*
  Integration note:
  Do not assume endpoint names or payload formats. Confirm them from the
  team's FastAPI /openapi.json or /docs, then wire page-specific functions.
*/
export async function sendChatMessage(message, history = []) {
  // Change this path and payload to match the backend's confirmed chat route.
  return apiRequest('/chat', {
    method: 'POST',
    body: JSON.stringify({ message, history }),
  })
}

export { API_BASE_URL }